package bots.LongTimeProcess;

public abstract class LongTimeProcess {
    abstract String getDescription();
}
