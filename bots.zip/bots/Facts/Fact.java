package bots.Facts;

public abstract class Fact {

    /**
     * @return Description of the fact
     */
    abstract public String getDescription();

}

