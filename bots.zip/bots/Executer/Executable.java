package bots.Executer;

public interface Executable {
    /**
     * execute this func
     */
    void execute();
    @Override
    String toString();
}
