package bots.Analyze.AnnouncmentShouter;

import bots.Facts.Announcement;
import penguin_game.Game;

import java.util.List;

public abstract class AnnouncementShouterAbs {
    public abstract List<Announcement> shout(Game game);
}
