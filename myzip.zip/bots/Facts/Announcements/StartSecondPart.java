package bots.Facts.Announcements;

import bots.Facts.Announcement;

public class StartSecondPart extends Announcement {
    @Override
    public String getDescription() {
        return "StartSecondPart";
    }
}
