package bots.LongTimeProcess;

import bots.DataBases.Pair;
import penguin_game.Iceberg;

import java.util.Vector;

public class LongTimeAttack extends LongTimeProcess{
    private Iceberg target;
    private Vector<Pair<Iceberg, Integer>> miniAttacks; //for each index in the vector we save from where we attack and how many peng attack

    public LongTimeAttack(Iceberg target, Vector<Pair<Iceberg, Integer>> miniAttacks) {
        this.target = target;
        this.miniAttacks = miniAttacks;
    }

    @Override
    String getDescription() {
        return "LongTimeAttack";
    }

    public Vector<Pair<Iceberg, Integer>> getMiniAttacks() {
        return miniAttacks;
    }

    public Iceberg getTarget() {
        return target;
    }
}
