package bots.Facts;

public abstract class Fact {
    private String description;

    public String getDescription() {
        return description;
    }
}

