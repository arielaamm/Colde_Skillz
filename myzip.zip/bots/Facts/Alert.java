package bots.Facts;

public abstract class Alert extends Fact {
}

