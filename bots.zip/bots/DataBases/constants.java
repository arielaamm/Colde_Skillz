package bots.DataBases;

public class constants {
    public static final int turnToSiegePar2 = 12;

    public static final int turnToClonePart2 = 5;

    public static final int turnToSiegePar1 = 15;

    static final int turnToIcepitalWorks = 4;

}
