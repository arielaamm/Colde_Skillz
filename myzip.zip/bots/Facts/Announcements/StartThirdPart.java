package bots.Facts.Announcements;

import bots.Facts.Announcement;

public class StartThirdPart extends Announcement {
    @Override
    public String getDescription() {
        return "StartThirdPart";
    }
}
