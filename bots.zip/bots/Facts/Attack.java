package bots.Facts;

public abstract class Attack extends Fact {
}
