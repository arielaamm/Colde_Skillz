package bots.Facts;

public abstract class Announcement extends Fact {
}
