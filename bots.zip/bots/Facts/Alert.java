package bots.Facts;

/**
 * {@code abststact class} <pre/>
 * Alert of samething is happening
 */
public abstract class Alert extends Fact {
    
}

